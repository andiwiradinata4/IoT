﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtPortName = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.cboParity = New System.Windows.Forms.ComboBox()
        Me.cboStopBits = New System.Windows.Forms.ComboBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.btnSetup = New System.Windows.Forms.Button()
        Me.btnReadExisting = New System.Windows.Forms.Button()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.btnReadFromWrite = New System.Windows.Forms.Button()
        Me.btnWrite = New System.Windows.Forms.Button()
        Me.txttCommand = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtDataBits = New System.Windows.Forms.NumericUpDown()
        Me.txtBaudRate = New System.Windows.Forms.NumericUpDown()
        Me.lblStatus = New System.Windows.Forms.Label()
        Me.rtbResult = New System.Windows.Forms.RichTextBox()
        Me.Panel1.SuspendLayout()
        CType(Me.txtDataBits, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtBaudRate, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(33, 25)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(57, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Port Name"
        '
        'txtPortName
        '
        Me.txtPortName.Location = New System.Drawing.Point(109, 22)
        Me.txtPortName.Name = "txtPortName"
        Me.txtPortName.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.txtPortName.Size = New System.Drawing.Size(124, 21)
        Me.txtPortName.TabIndex = 0
        Me.txtPortName.Text = "COM1"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(33, 51)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(57, 13)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Baud Rate"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(33, 77)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(50, 13)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Data Bits"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(33, 106)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(35, 13)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "Parity"
        '
        'cboParity
        '
        Me.cboParity.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboParity.Items.AddRange(New Object() {"0 - NONE", "1 - ODD", "2 - EVEN", "3 - MARK", "4 - SPACE"})
        Me.cboParity.Location = New System.Drawing.Point(109, 103)
        Me.cboParity.Name = "cboParity"
        Me.cboParity.Size = New System.Drawing.Size(124, 21)
        Me.cboParity.TabIndex = 3
        '
        'cboStopBits
        '
        Me.cboStopBits.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboStopBits.Items.AddRange(New Object() {"1", "1.5", "2"})
        Me.cboStopBits.Location = New System.Drawing.Point(109, 130)
        Me.cboStopBits.Name = "cboStopBits"
        Me.cboStopBits.Size = New System.Drawing.Size(124, 21)
        Me.cboStopBits.TabIndex = 4
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(33, 133)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(49, 13)
        Me.Label5.TabIndex = 9
        Me.Label5.Text = "Stop Bits"
        '
        'btnSetup
        '
        Me.btnSetup.Location = New System.Drawing.Point(33, 195)
        Me.btnSetup.Name = "btnSetup"
        Me.btnSetup.Size = New System.Drawing.Size(200, 23)
        Me.btnSetup.TabIndex = 5
        Me.btnSetup.Text = "Setup"
        Me.btnSetup.UseVisualStyleBackColor = True
        '
        'btnReadExisting
        '
        Me.btnReadExisting.Location = New System.Drawing.Point(33, 224)
        Me.btnReadExisting.Name = "btnReadExisting"
        Me.btnReadExisting.Size = New System.Drawing.Size(200, 23)
        Me.btnReadExisting.TabIndex = 6
        Me.btnReadExisting.Text = "Read Existing"
        Me.btnReadExisting.UseVisualStyleBackColor = True
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.btnReadFromWrite)
        Me.Panel1.Controls.Add(Me.btnWrite)
        Me.Panel1.Controls.Add(Me.txttCommand)
        Me.Panel1.Controls.Add(Me.Label6)
        Me.Panel1.Controls.Add(Me.txtDataBits)
        Me.Panel1.Controls.Add(Me.txtBaudRate)
        Me.Panel1.Controls.Add(Me.lblStatus)
        Me.Panel1.Controls.Add(Me.txtPortName)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.btnReadExisting)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.btnSetup)
        Me.Panel1.Controls.Add(Me.cboStopBits)
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Controls.Add(Me.Label5)
        Me.Panel1.Controls.Add(Me.cboParity)
        Me.Panel1.Controls.Add(Me.Label4)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(261, 409)
        Me.Panel1.TabIndex = 0
        '
        'btnReadFromWrite
        '
        Me.btnReadFromWrite.Location = New System.Drawing.Point(33, 282)
        Me.btnReadFromWrite.Name = "btnReadFromWrite"
        Me.btnReadFromWrite.Size = New System.Drawing.Size(200, 23)
        Me.btnReadFromWrite.TabIndex = 17
        Me.btnReadFromWrite.Text = "Read From Write"
        Me.btnReadFromWrite.UseVisualStyleBackColor = True
        '
        'btnWrite
        '
        Me.btnWrite.Location = New System.Drawing.Point(33, 253)
        Me.btnWrite.Name = "btnWrite"
        Me.btnWrite.Size = New System.Drawing.Size(200, 23)
        Me.btnWrite.TabIndex = 16
        Me.btnWrite.Text = "Write"
        Me.btnWrite.UseVisualStyleBackColor = True
        '
        'txttCommand
        '
        Me.txttCommand.Location = New System.Drawing.Point(109, 157)
        Me.txttCommand.Name = "txttCommand"
        Me.txttCommand.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.txttCommand.Size = New System.Drawing.Size(124, 21)
        Me.txttCommand.TabIndex = 14
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(33, 160)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(54, 13)
        Me.Label6.TabIndex = 15
        Me.Label6.Text = "Command"
        '
        'txtDataBits
        '
        Me.txtDataBits.Location = New System.Drawing.Point(109, 76)
        Me.txtDataBits.Maximum = New Decimal(New Integer() {99999999, 0, 0, 0})
        Me.txtDataBits.Name = "txtDataBits"
        Me.txtDataBits.Size = New System.Drawing.Size(124, 21)
        Me.txtDataBits.TabIndex = 2
        Me.txtDataBits.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.txtDataBits.Value = New Decimal(New Integer() {8, 0, 0, 0})
        '
        'txtBaudRate
        '
        Me.txtBaudRate.Location = New System.Drawing.Point(109, 49)
        Me.txtBaudRate.Maximum = New Decimal(New Integer() {99999999, 0, 0, 0})
        Me.txtBaudRate.Name = "txtBaudRate"
        Me.txtBaudRate.Size = New System.Drawing.Size(124, 21)
        Me.txtBaudRate.TabIndex = 1
        Me.txtBaudRate.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.txtBaudRate.Value = New Decimal(New Integer() {9600, 0, 0, 0})
        '
        'lblStatus
        '
        Me.lblStatus.AutoSize = True
        Me.lblStatus.Font = New System.Drawing.Font("Tahoma", 8.0!)
        Me.lblStatus.ForeColor = System.Drawing.Color.Indigo
        Me.lblStatus.Location = New System.Drawing.Point(29, 342)
        Me.lblStatus.Name = "lblStatus"
        Me.lblStatus.Size = New System.Drawing.Size(38, 13)
        Me.lblStatus.TabIndex = 13
        Me.lblStatus.Text = "Status"
        '
        'rtbResult
        '
        Me.rtbResult.Dock = System.Windows.Forms.DockStyle.Fill
        Me.rtbResult.Location = New System.Drawing.Point(261, 0)
        Me.rtbResult.Name = "rtbResult"
        Me.rtbResult.Size = New System.Drawing.Size(363, 409)
        Me.rtbResult.TabIndex = 1
        Me.rtbResult.Text = ""
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(624, 409)
        Me.Controls.Add(Me.rtbResult)
        Me.Controls.Add(Me.Panel1)
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.Name = "Form1"
        Me.Text = "Main"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.txtDataBits, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtBaudRate, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents txtPortName As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents cboParity As ComboBox
    Friend WithEvents cboStopBits As ComboBox
    Friend WithEvents Label5 As Label
    Friend WithEvents btnSetup As Button
    Friend WithEvents btnReadExisting As Button
    Friend WithEvents Panel1 As Panel
    Friend WithEvents rtbResult As RichTextBox
    Friend WithEvents lblStatus As Label
    Friend WithEvents txtBaudRate As NumericUpDown
    Friend WithEvents txtDataBits As NumericUpDown
    Friend WithEvents btnWrite As Button
    Friend WithEvents txttCommand As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents btnReadFromWrite As Button
End Class
