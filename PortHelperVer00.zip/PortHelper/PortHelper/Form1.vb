﻿Imports System.IO.Ports

Public Class Form1

    Private ioPort As SerialPort

    Private Sub SettingSerialPort()
        ioPort = New SerialPort
        Try
            With ioPort
                .DtrEnable = True
                .PortName = txtPortName.Text.Trim
                .BaudRate = txtBaudRate.Value
                .DataBits = txtDataBits.Value

                Select Case cboParity.SelectedIndex
                    Case 0 : .Parity = IO.Ports.Parity.None
                    Case 1 : .Parity = IO.Ports.Parity.Odd
                    Case 2 : .Parity = IO.Ports.Parity.Even
                    Case 3 : .Parity = IO.Ports.Parity.Mark
                    Case 4 : .Parity = IO.Ports.Parity.Space
                End Select

                Select Case cboStopBits.SelectedIndex
                    Case 0 : .StopBits = IO.Ports.StopBits.One
                    Case 1 : .StopBits = IO.Ports.StopBits.OnePointFive
                    Case 2 : .StopBits = IO.Ports.StopBits.Two
                End Select
            End With
            lblStatus.Text = "SETUP SUCCESS ....... "
        Catch ex As Exception
            lblStatus.Text = "SETUP ERROR ....... " & ex.Message
            MessageBox.Show(ex.Message, "Setting Serial Port")
        End Try
    End Sub

    Private Sub OpenIO()
        Try
            ioPort.Open()
            lblStatus.Text = "OPEN PORT SUCCESS ....... "
        Catch ex As Exception
            lblStatus.Text = "OPEN PORT FAIL ....... " & ex.Message
            MessageBox.Show(ex.Message, "Open Serial Port")
        End Try
    End Sub

    Private Sub CloseIO()
        Try
            If (ioPort.IsOpen) Then
                ioPort.Close()
            End If
            lblStatus.Text = "CLOSE PORT SUCCESS ....... "
        Catch ex As Exception
            lblStatus.Text = "CLOSE PORT FAIL ....... " & ex.Message
            MessageBox.Show(ex.Message, "Close Serial Port")
        End Try
    End Sub

    Private Sub ReadExisting()
        Try
            rtbResult.Text = ioPort.ReadExisting
            lblStatus.Text = "READ SUCCESS ....... "
        Catch ex As Exception
            lblStatus.Text = "READ FAIL ....... " & ex.Message
            MessageBox.Show(ex.Message, "Read Existing")
        End Try
    End Sub

    Private Sub Write()
        Try
            ioPort.Write(txttCommand.Text.Trim)
            lblStatus.Text = "WRITE SUCCESS ....... "
            Threading.Thread.Sleep(1000)
        Catch ex As Exception
            lblStatus.Text = "WRITE FAIL ....... " & ex.Message
            MessageBox.Show(ex.Message, "Write Port")
        End Try
    End Sub

#Region "Form Handle"

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        txtPortName.Text = "COM1"
        txtBaudRate.Value = 9600
        txtDataBits.Value = 8
        cboParity.SelectedIndex = 0
        cboStopBits.SelectedIndex = 0
    End Sub

    Private Sub btnSetup_Click(sender As Object, e As EventArgs) Handles btnSetup.Click
        SettingSerialPort()
    End Sub

    Private Sub btnReadExisting_Click(sender As Object, e As EventArgs) Handles btnReadExisting.Click
        SettingSerialPort()
        OpenIO()
        ReadExisting()
        CloseIO()
    End Sub

    Private Sub btnWrite_Click(sender As Object, e As EventArgs) Handles btnWrite.Click
        SettingSerialPort()
        OpenIO()
        Write()
    End Sub

    Private Sub btnReadFromWrite_Click(sender As Object, e As EventArgs) Handles btnReadFromWrite.Click
        ReadExisting()
    End Sub

#End Region

End Class
